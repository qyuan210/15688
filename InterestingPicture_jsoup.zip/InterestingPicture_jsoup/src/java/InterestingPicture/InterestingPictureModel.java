package InterestingPicture;

/*
 * @author Joe Mertz, modified by Yuan Qin 
 * 
 * This file is the Model component of the MVC, and it models the business
 * logic for the web application.  In this case, the business logic involves
 * making a request to flickr.com and then screen scraping the HTML that is
 * returned in order to fabricate an image URL.
 */
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Random;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;


public class InterestingPictureModel {

    /**
     * Arguments.
     *
     * @param searchTag The tag of the photo to be searched for.
     * @param picSize The string "mobile" or "desktop" indicating the size of
     * photo requested.
     */
    public String doFlickrSearch(String searchTag, String picSize) 
            throws UnsupportedEncodingException  {
        /*
         * URL encode the searchTag, e.g. to encode spaces as %20
         *
         * There is no reason that UTF-8 would be unsupported.  It is the
         * standard encoding today.  So if it is not supported, we have
         * big problems, so don't catch the exception.
         */
        searchTag = URLEncoder.encode(searchTag, "UTF-8");
 
        String response = "";

        // Create a URL for the page to be screen scraped
        String flickrURL =
                "https://www.flickr.com/search/?text="
                + searchTag
                +"&license=2%2C3%2C4%2C5%2C6%2C9";
        
        /*
         * Search the page to fid the picture URL
         *
         * Screen scraping is an art that requires creatively looking at the
         * HTML that is returned and figuring out how to cut out the data that 
         * is important to you.
         *
         * These particular searches were crafted by carefully looking at 
         * the HTML that Flickr returned, and finding (by experimentation) the
         * generalizable steps that will reliably get a picture URL.
         * 
         * Jsoup is a library to work with HTML based content, which provides
         * convenient API to extract and manipulate data, using the bset of 
         * DOM, CSS and jquery-like methods.
         */
        
        try {
            //Instead of using fetch(), 
            //use Jsoup method to fetch and parse HTML documet from the web
            Document doc = Jsoup.connect(flickrURL).get();
            //First find the HTML elements which we want to extract data from
            Elements divElements = doc.select("div[class=view photo-list-photo-view requiredToShowOnServer awake]");
            
            //If size=0, then no picture is found
            if (divElements.size() == 0) {
                System.out.println("pictureURL= null");
                return (String) null;
            }
            
            //Instead of choosing the first image, let's randomly choose an image 
            //This better shows why Jsoup is useful compare with substring method
            Random r = new Random();
            int i = r.nextInt(divElements.size());
            response = divElements.get(i).attr("style");
            
            //Because for the flickr page, the pictureurl we want to extract is set 
            //as a text information in the html, so we still need to use the substring method
            //But in many other situations, you may find Jsoup very powerful to 
            //help locate and find the things you want to extract
            int cutLeft = response.indexOf("background-image: url(");
            
            // Skip past this string. 
            cutLeft += "background-image: url(".length();
            
            // The next character would be the // which in a URL separates the 
            // protocol from the server (i.e. https://foo.com)

            // Look for the close parenthesis
            int cutRight = response.indexOf(")", cutLeft);

            // Now snip out the part from positions cutLeft to cutRight
            // and prepend the protocol (i.e. https).
            String pictureURL = "https:"+response.substring(cutLeft, cutRight);
            pictureURL = interestingPictureSize(pictureURL, picSize);
            System.out.println("pictureURL= " + pictureURL);
            return pictureURL;
        } catch (IOException ex) {
            System.out.println("pictureURL= null");
            return (String) null;
        }    
    }

    /*
     * Return a URL of an image of appropriate size
     * 
     * Arguments
     * @param picSize The string "mobile" or "desktop" indicating the size of
     * photo requested.
     * @return The URL an image of appropriate size.
     */
    private String interestingPictureSize(String pictureURL, String picSize) {
        int finalDot = pictureURL.lastIndexOf(".");
        /*
         * From the flickr online documentation, an underscore and a letter 
         * before the final "." and file extension is a size indicator.  
         * "_m" for small and "-z" for big.
         */
        String sizeLetter = (picSize.equals("mobile")) ? "m" : "z";
        if (pictureURL.indexOf("_", finalDot-2) == -1) {
            // If the URL currently did not have a _? size indicator, add it.
            return (pictureURL.substring(0, finalDot) + "_" + sizeLetter
                + pictureURL.substring(finalDot));
        } else {
            // Else just change it
            return (pictureURL.substring(0, finalDot - 1) + sizeLetter
                + pictureURL.substring(finalDot));
        }
    }
}
